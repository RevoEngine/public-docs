import http from "node:http";
import { execFile } from "node:child_process";
import fs from "node:fs/promises";
import { pathToFileURL } from "node:url";
import { Readable } from "node:stream";
import { pipeline } from "node:stream/promises";

const publicFiles = new Map([
  ["/", ["index.html", "text/html"]],
  ["/chat.mjs", ["chat.mjs", "text/javascript"]],
  ["/sse-parser.mjs", ["sse-parser.mjs", "text/javascript"]],
  ["/component.txt", ["component.txt", "text/plain"]],
]);

export function createDemoServer({ authorization, upstream, instance }) {
  if (!authorization || !upstream)
    throw new Error("Configure RevoEngine credentials and the Endpoint URL.");
  const target = new URL(upstream);
  if (
    !["http:", "https:"].includes(target.protocol) ||
    target.username ||
    target.password
  ) {
    throw new Error(
      "Use an HTTP(S) Endpoint URL without embedded credentials.",
    );
  }

  const server = http.createServer(async (req, res) => {
    const port = server.address().port;
    res.setHeader("Cache-Control", "no-store");
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader(
      "Content-Security-Policy",
      "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'",
    );
    if (req.headers.host !== `localhost:${port}`) {
      res.writeHead(403).end();
      return;
    }

    if (req.method === "GET" && publicFiles.has(req.url)) {
      const [name, type] = publicFiles.get(req.url);
      try {
        const data = await fs.readFile(new URL(name, import.meta.url));
        res
          .writeHead(200, { "Content-Type": type + "; charset=utf-8" })
          .end(data);
      } catch {
        res.writeHead(404).end("File not found.");
      }
      return;
    }
    if (req.url !== "/api/run" || req.method !== "POST") {
      res.writeHead(404).end();
      return;
    }
    if (
      req.headers.origin !== `http://${req.headers.host}` ||
      req.headers["sec-fetch-site"] === "cross-site"
    ) {
      res.writeHead(403).end();
      return;
    }
    if (!String(req.headers["content-type"]).startsWith("application/json")) {
      res.writeHead(415).end();
      return;
    }

    const disconnected = new AbortController();
    // A browser abort must also close this request's upstream SSE connection.
    res.once("close", () => disconnected.abort());
    try {
      const chunks = [];
      let size = 0;
      for await (const part of req) {
        size += part.length;
        if (size > 16384) {
          res.writeHead(413).end();
          return;
        }
        chunks.push(part);
      }
      const raw = Buffer.concat(chunks).toString("utf8");
      try {
        JSON.parse(raw);
      } catch {
        res.writeHead(400).end("Invalid JSON.");
        return;
      }

      const response = await fetch(target, {
        method: "POST",
        headers: {
          Authorization: authorization,
          "Content-Type": "application/json",
          ...(instance ? { instance } : {}),
          ...(req.headers["last-event-id"]
            ? { "Last-Event-ID": req.headers["last-event-id"] }
            : {}),
        },
        body: raw,
        signal: AbortSignal.any([
          disconnected.signal,
          AbortSignal.timeout(70000),
        ]),
      });
      res.writeHead(response.status, {
        "Content-Type":
          response.headers.get("content-type") || "application/json",
        "X-Accel-Buffering": "no",
      });
      res.flushHeaders();
      // pipeline forwards bytes incrementally and preserves backpressure.
      if (response.body) await pipeline(Readable.fromWeb(response.body), res);
      else res.end();
    } catch {
      if (!res.destroyed && !disconnected.signal.aborted) {
        if (!res.headersSent)
          res
            .writeHead(502, { "Content-Type": "application/json" })
            .end(
              JSON.stringify({
                message:
                  "The Endpoint is unavailable or the request timed out.",
              }),
            );
        else res.destroy();
      }
    }
  });
  return server;
}

export function startDemo() {
  const port = Number(process.env.DEMO_PORT ?? 4318);
  if (!Number.isInteger(port) || port < 1024 || port > 65535)
    throw new Error("Invalid DEMO_PORT.");
  const server = createDemoServer({
    authorization: process.env.REVO_AUTHORIZATION,
    upstream: process.env.REVO_ENDPOINT_URL,
    instance: process.env.REVO_INSTANCE,
  });
  server.listen(port, "localhost", () => {
    const url = `http://localhost:${port}`;
    console.log(`SSE chat: ${url}. Ctrl+C stops the server.`);
    if (process.argv.includes("--open") && process.platform === "darwin") {
      execFile("/usr/bin/open", ["-a", "Google Chrome", url], (error) => {
        if (error) console.log(`Open ${url} in Chrome.`);
      });
    }
  });
  server.on("error", (error) => {
    console.error(
      error.code === "EADDRINUSE"
        ? `Port ${port} is already in use.`
        : "Unable to start the local chat.",
    );
    process.exitCode = 1;
  });
  return server;
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href)
  startDemo();
