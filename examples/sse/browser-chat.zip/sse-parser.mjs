// Incremental SSE parser: CR, LF, CRLF, split chunks and multiline data.
export function createSseParser(onFrame) {
  let line = "",
    skipLF = false,
    first = true;
  let event = "",
    data = [],
    id,
    retry;
  function consume() {
    if (line === "") {
      if (data.length)
        onFrame({
          event: event || "message",
          data: data.join("\n"),
          ...(id !== undefined ? { id } : {}),
          ...(retry !== undefined ? { retry } : {}),
        });
      event = "";
      data = [];
      id = undefined;
      retry = undefined;
    } else if (!line.startsWith(":")) {
      const colon = line.indexOf(":");
      const field = colon < 0 ? line : line.slice(0, colon);
      let value = colon < 0 ? "" : line.slice(colon + 1);
      if (value.startsWith(" ")) value = value.slice(1);
      if (field === "event") event = value;
      if (field === "data") data.push(value);
      if (field === "id" && !value.includes("\0")) id = value;
      if (field === "retry" && /^\d+$/.test(value)) retry = Number(value);
    }
    line = "";
  }
  return {
    push(chunk) {
      for (const ch of chunk) {
        if (first) {
          first = false;
          if (ch === "\uFEFF") continue;
        }
        if (skipLF) {
          skipLF = false;
          if (ch === "\n") continue;
        }
        if (ch === "\r") {
          consume();
          skipLF = true;
        } else if (ch === "\n") consume();
        else line += ch;
      }
    },
  };
}
